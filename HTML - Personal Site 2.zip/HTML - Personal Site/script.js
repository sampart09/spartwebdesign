const navLinks = document.querySelectorAll('.nav-link');

navLinks.forEach(link => {
  link.addEventListener('mouseenter', event => {
    event.target.style.color = '#ff6202';
  });
  
  link.addEventListener('mouseleave', event => {
    event.target.style.color = 'white';
  });
});

const burger = document.querySelector('.burger');

burger.addEventListener('click', () => {
  burger.classList.toggle('open');
});

