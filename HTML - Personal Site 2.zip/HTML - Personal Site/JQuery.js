$(document).ready(function () {
  $("nav a").click(function () {
    var sectionId = $(this).attr("href");
    $(sectionId).slideToggle();
  });
});
